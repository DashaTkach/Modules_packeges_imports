from unittest import TestCase


class TestPreprocessing(TestCase):
    def test_imputation(self):
        self.assertEqual(0, 0)

    def test_outliers(self):
        self.assertEqual(0, 0)


class TestDimReduction(TestCase):
    def test_dim_reduction(self):
        self.assertEqual(0, 0)


class TestClustering(TestCase):
    def test_clustering(self):
        self.assertEqual(0, 0)


class TestClassifier(TestCase):
    def test_classifier(self):
        self.assertEqual(0, 0)
